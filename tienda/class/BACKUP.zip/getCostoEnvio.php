<?php

$costoEnvio = 7;

