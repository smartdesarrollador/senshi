<?php

define("SERVIDOR", "localhost");
define("USUARIO", "senshi_senshi");
define("PASSWORD", "Eam!LH15E+([");
define("BASEDATOS", "senshi_senshi");
/*define("COSTOENVIO", $costoEnvio);*/
