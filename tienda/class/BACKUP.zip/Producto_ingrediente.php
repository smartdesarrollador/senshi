<?php
/**
 * Created by PhpStorm.
 * Developer: Johen Guevara Santos.
 * Email: mguevara@enfocussoluciones.com
 * Date: 25/09/2019
 * Time: 12:17
 */
require_once "ConexionBD.class.php";
require_once("AccesoBD.class.php");

class Producto_ingrediente
{
    private $cn;

    //EL CONSTRUCTOR CONSTRUYE LA VARIABLE $cn
    function __construct()
    {
        try {
            $con = ConexionBD::CadenaCN();
            $this->cn = AccesoBD::ConexionBD($con);
            $this->cn->query("SET NAMES 'utf8'");   //ACENTOS UTF8
        } catch (Exception $e) {
            throw $e;
        }
    }


    public function getIngredientesByIdProducto($idProducto)
    {
        try {
            $sql = "SELECT * FROM producto_ingrediente INNER JOIN 
ingrediente ON producto_ingrediente.idIngrediente = ingrediente.idIngrediente 
WHERE producto_ingrediente.idProducto='$idProducto' AND ingrediente.estado = 'ACTIVO' ORDER BY ingrediente.nombre";
            $lista = AccesoBD::Consultar($this->cn, $sql);
            return $lista;
        } catch (Exception $e) {
            $mensaje = "Fecha: " . date("Y-m-d H:i:s") . "\n" .
                "Archivo: " . $e->getFile() . "\n" .
                "Linea: " . $e->getLine() . "\n" .
                "Mensaje: " . $sql . "\n\n";
            error_log($mensaje, 3, "log/proyecto.log");
            throw $e;
        }
    }
    public function getIngredientesByIdProductoAndTipo($idProducto,$tipo,$orden)
    {
        try {
            $sql = "SELECT * FROM producto_ingrediente INNER JOIN 
ingrediente ON producto_ingrediente.idIngrediente = ingrediente.idIngrediente 
WHERE producto_ingrediente.idProducto='$idProducto' AND ingrediente.estado = 'ACTIVO' AND ingrediente.tipo = '$tipo'
ORDER BY $orden ASC ";
            $lista = AccesoBD::Consultar($this->cn, $sql);
            return $lista;
        } catch (Exception $e) {
            $mensaje = "Fecha: " . date("Y-m-d H:i:s") . "\n" .
                "Archivo: " . $e->getFile() . "\n" .
                "Linea: " . $e->getLine() . "\n" .
                "Mensaje: " . $sql . "\n\n";
            error_log($mensaje, 3, "log/proyecto.log");
            throw $e;
        }
    }

    public function getAllIngredientes()
    {
        try {
            $sql = "SELECT	* FROM	producto_ingrediente 
INNER JOIN ingrediente ON producto_ingrediente.idIngrediente = ingrediente.idIngrediente
WHERE ingrediente.estado = 'ACTIVO'";
            $lista = AccesoBD::Consultar($this->cn, $sql);
            return $lista;
        } catch (Exception $e) {
            $mensaje = "Fecha: " . date("Y-m-d H:i:s") . "\n" .
                "Archivo: " . $e->getFile() . "\n" .
                "Linea: " . $e->getLine() . "\n" .
                "Mensaje: " . $sql . "\n\n";
            error_log($mensaje, 3, "log/proyecto.log");
            throw $e;
        }
    }


}
